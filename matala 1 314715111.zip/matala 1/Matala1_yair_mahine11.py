# -*- coding: utf-8 -*-
"""
Created on Sun Apr 16 14:23:56 2023

@author: 97254
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load data from CSV
data = pd.read_csv('sample.csv')

# Initialize parameters
a = 0
b = 0

# Set hyperparameters
learning_rates = [0.0001, 0.1]
batch_size = 10
num_epochs = 1000

# Gradient Descent
def gradient_descent(data, a, b, learning_rate, num_epochs):
    loss = []
    a_vals = []
    b_vals = []
    for i in range(num_epochs):
        y_pred = a * data['x'] + b
        error = y_pred - data['y']
        mse = np.mean(error ** 2)
        gradient_a = 2 * np.mean(error * data['x'])
        gradient_b = 2 * np.mean(error)
        a -= learning_rate * gradient_a
        b -= learning_rate * gradient_b
        loss.append(mse)
        a_vals.append(a)
        b_vals.append(b)
    return loss, a_vals, b_vals

# Stochastic Gradient Descent
def stochastic_gradient_descent(data, a, b, learning_rate, num_epochs):
    loss = []
    a_vals = []
    b_vals = []
    for i in range(num_epochs):
        rand_idx = np.random.randint(len(data))
        x = data['x'][rand_idx]
        y = data['y'][rand_idx]
        y_pred = a * x + b
        error = y_pred - y
        mse = error ** 2
        gradient_a = 2 * error * x
        gradient_b = 2 * error
        a -= learning_rate * gradient_a
        b -= learning_rate * gradient_b
        loss.append(mse)
        a_vals.append(a)
        b_vals.append(b)
    return loss, a_vals, b_vals

# Mini-batch Gradient Descent
def minibatch_gradient_descent(data, a, b, learning_rate, batch_size, num_epochs):
    loss = []
    a_vals = []
    b_vals = []
    for i in range(num_epochs):
        rand_idxs = np.random.choice(len(data), size=batch_size, replace=False)
        x = data['x'][rand_idxs]
        y = data['y'][rand_idxs]
        y_pred = a * x + b
        error = y_pred - y
        mse = np.mean(error ** 2)
        gradient_a = 2 * np.mean(error * x)
        gradient_b = 2 * np.mean(error)
        a -= learning_rate * gradient_a
        b -= learning_rate * gradient_b
        loss.append(mse)
        a_vals.append(a)
        b_vals.append(b)
    return loss, a_vals, b_vals

# Loop through learning rates and plot results
for learning_rate in learning_rates:
    gd_loss, gd_a, gd_b = gradient_descent(data, a, b, learning_rate, num_epochs)
    sgd_loss, sgd_a, sgd_b = stochastic_gradient_descent(data, a, b, learning_rate, num_epochs)
    mbgd_loss, mbgd_a, mbgd_b = minibatch_gradient_descent(data, a, b, learning_rate, batch_size, num_epochs)

# Gradient Descent
fig, axs = plt.subplots(3, 2, figsize=(12, 12))

for i, lr in enumerate(learning_rates):
    losses, a_vals, b_vals = gradient_descent(data, a, b, lr, num_epochs)
    axs[0, i].plot(losses)
    axs[0, i].set_title(f"Loss (lr={lr})")
    axs[1, i].plot(a_vals)
    axs[1, i].set_title(f"a (lr={lr})")
    axs[2, i].plot(b_vals)
    axs[2, i].set_title(f"b (lr={lr})")

# Stochastic Gradient Descent
fig, axs = plt.subplots(3, 2, figsize=(12, 12))

for i, lr in enumerate(learning_rates):
    losses, a_vals, b_vals = stochastic_gradient_descent(data, a, b, lr, num_epochs)
    axs[0, i].plot(losses)
    axs[0, i].set_title(f"Loss (lr={lr})")
    axs[1, i].plot(a_vals)
    axs[1, i].set_title(f"a (lr={lr})")
    axs[2, i].plot(b_vals)
    axs[2, i].set_title(f"b (lr={lr})")

# Mini-batch Gradient Descent
fig, axs = plt.subplots(3, 2, figsize=(12, 12))

for i, lr in enumerate(learning_rates):
    losses, a_vals, b_vals = minibatch_gradient_descent(data, a, b, lr, batch_size, num_epochs)
    axs[0, i].plot(losses)
    axs[0, i].set_title(f"Loss (lr={lr})")
    axs[1, i].plot(a_vals)
    axs[1, i].set_title(f"a (lr={lr})")
    axs[2, i].plot(b_vals)
    axs[2, i].set_title(f"b (lr={lr})")

plt.show()





